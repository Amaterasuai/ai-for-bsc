from embedchain.bots.whatsapp import WhatsAppBot


def main():
    whatsapp_bot = WhatsAppBot()
    whatsapp_bot.start()


if __name__ == "__main__":
    main()
