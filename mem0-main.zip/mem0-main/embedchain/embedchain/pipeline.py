from embedchain.app import App


class Pipeline(App):
    """
    This is deprecated. Use `App` instead.
    """

    pass
